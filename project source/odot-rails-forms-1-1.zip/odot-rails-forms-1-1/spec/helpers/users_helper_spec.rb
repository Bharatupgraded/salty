require 'spec_helper'

describe UsersHelper do

end
